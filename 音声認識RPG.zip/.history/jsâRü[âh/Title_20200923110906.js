var img = new Image();
