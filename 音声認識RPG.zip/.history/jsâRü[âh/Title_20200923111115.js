var cvs = document.getElementById('cv');
var ctx = cvs.getContext('2d');

var img = new Image();
img.src = "pipo-bg001a.jpg"

img.