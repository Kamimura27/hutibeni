window.onload = () => {
var cvs = document.getElementById('cv');
var ctx = cvs.getContext('2d');

var img = new Image();
img.src = "./画像/pipo-bg001a.jpg"

img.on
ctx.drawImage(img, 0, 0);
};