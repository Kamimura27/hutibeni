window.onload = () => {
    var cvs = document.getElementById('cv');
    var ctx = cvs.getContext('2d');

    var img = new Image();
    img.src = "./画像/pipo-bg001a.jpg"

    img.addEventListener('load', function () {
        ctx.drawImage(img, 0, 0, 1024, 768);
        writeTitle();
        writeSTART();
    })

    function writeTitle() {
        ctx.font = 'bold 60pt Arial';
        ctx.fillStyle = '#bbb';
        ctx.fillText('音声認識RPG', 262, 264);
        ctx.fillStyle = 'orange';
        ctx.fillText('音声認識RPG', 256, 270);
        ctx.strokeStyle = 'red';
        ctx.lineWidth = 2;
        ctx.strokeText('音声認識RPG', 256, 270);

    };

    function writeSTART() {
        ctx.font = 'bold 48pt Arial';
        ctx.fillStyle = 'orange';
        ctx.fillText('START', 3, 576);
        /*ctx.strokeStyle = 'red';
        ctx.lineWidth = 2;
        ctx.strokeText('音声認識RPG', 256, 270);*/
    }


};


