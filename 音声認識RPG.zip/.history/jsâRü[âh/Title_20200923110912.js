var img = new Image();
img.s