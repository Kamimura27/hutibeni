window.onload = () => {
    var cvs = document.getElementById('cv');
    var ctx = cvs.getContext('2d');

    /*var img = new Image();
    img.src = "./画像/pipo-bg001a.jpg"

    img.onload = () => {
        ctx.drawImage(img, 0, 0, 1024, 768);
    };*/
    function writeText() {
        ctx.font = '60pt Arial';
        ctx.fillStyle = '#6080A0';
        ctx.fillText('音声認識RPG', 256, 192);
    };
    writeText();

};


