var img = new Image();
img.src = ""