var img = new Image();
img.src = "pipo-bg001a.jpg"